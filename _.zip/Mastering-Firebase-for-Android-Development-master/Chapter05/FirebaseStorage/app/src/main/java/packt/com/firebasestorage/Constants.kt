package packt.com.firebasestorage

/**
 * Created by ashok on 02/04/18.
 */
class Constants {
    companion object {
        val STORAGE_PATH_UPLOADS = "uploads/"
        val DATABASE_PATH_UPLOADS = "uploads"
    }
}